export const PaLanguageSupport = {
    en: { nativeName: 'English', langKey: 'English' },
    hi: { nativeName: 'Hindi', langKey: 'हिंदी' }
};